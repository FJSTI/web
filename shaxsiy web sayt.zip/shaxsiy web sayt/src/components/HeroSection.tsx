
import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import WaveDecoration from './WaveDecoration';
import AuthForm from './AuthForm';
import ChatInterface from './ChatInterface';

const HeroSection = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  return (
    <section className="relative min-h-screen flex flex-col items-center justify-center py-12 px-4 overflow-hidden">
      <WaveDecoration />
      
      <div className="container relative z-10 max-w-6xl">
        <div className="flex flex-col lg:flex-row items-center gap-12">
          {/* Left side - Hero content */}
          <div className="flex-1 text-center lg:text-left">
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-oasis-800 mb-6">
              Welcome to <span className="text-oasis-500">Salom</span> <br /> Your Chat Oasis
            </h1>
            <p className="text-lg text-muted-foreground mb-8 max-w-2xl">
              Discover a peaceful sanctuary for meaningful conversations. 
              Connect, share, and build relationships in our tranquil digital oasis.
            </p>
            
            {!isAuthenticated && (
              <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
                <Button 
                  className="bg-oasis-gradient hover:opacity-90 transition-all text-lg px-8 py-6" 
                  size="lg"
                  onClick={() => window.scrollTo({
                    top: document.getElementById('auth-section')?.offsetTop,
                    behavior: 'smooth'
                  })}
                >
                  Get Started
                </Button>
                <Button variant="outline" size="lg" className="border-oasis-300 text-oasis-700 hover:bg-oasis-50 text-lg px-8 py-6">
                  Learn More
                </Button>
              </div>
            )}
          </div>
          
          {/* Right side - Auth form or Chat interface */}
          <div className="flex-1 w-full max-w-md">
            <div className="relative">
              {/* Decorative elements */}
              <div className="absolute -top-6 -left-6 w-12 h-12 rounded-full bg-oasis-200 z-0 animate-float" />
              <div className="absolute -bottom-8 -right-8 w-20 h-20 rounded-full bg-sand-200 z-0 animate-float" style={{ animationDelay: '1s' }} />
              
              {/* Auth form or Chat interface */}
              <div className="relative z-10">
                {isAuthenticated ? (
                  <div className="h-[600px] shadow-xl rounded-xl overflow-hidden">
                    <ChatInterface />
                  </div>
                ) : (
                  <div className="bg-white/80 backdrop-blur-sm rounded-xl p-1 shadow-xl">
                    <div id="auth-section">
                      <AuthForm onComplete={() => setIsAuthenticated(true)} />
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
