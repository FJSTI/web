
import React from 'react';

interface Testimonial {
  quote: string;
  author: string;
  position: string;
}

const Testimonials = () => {
  const testimonials: Testimonial[] = [
    {
      quote: "Xondamir bilan ishlash — bu sifat va professional yondashuv. Har bir detal e'tiborda.",
      author: "Murodjon T.",
      position: "startup asoschisi"
    },
    {
      quote: "Uning yaratuvchanligi va kodlashdagi aniqligi meni lol qoldirdi.",
      author: "Feruza A.",
      position: "loyihalar menejeri"
    },
    {
      quote: "Eng murakkab vazifalarni ham o'z vaqtida va sifatli bajaradi.",
      author: "Sardor K.",
      position: "IT menejer"
    }
  ];

  return (
    <section id="testimonials" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12 animate-fade-in">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">Fikrlar</span>
          </h2>
          <div className="w-16 h-1.5 bg-blue-purple-gradient rounded-full mx-auto mb-4"></div>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Mijozlarning men haqimdagi fikrlari
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div 
              key={index}
              className="bg-white p-6 rounded-lg shadow-sm border border-gray-100 animate-fade-in"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div className="mb-4">
                <svg className="w-8 h-8 text-blue-300" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M14.017 21v-7.391c0-5.704 3.731-9.57 8.983-10.609l.995 2.151c-2.432.917-3.995 3.638-3.995 5.849h4v10h-9.983zm-14.017 0v-7.391c0-5.704 3.748-9.57 9-10.609l.996 2.151c-2.433.917-3.996 3.638-3.996 5.849h3.983v10h-9.983z" />
                </svg>
              </div>
              <p className="text-gray-700 mb-6">
                {testimonial.quote}
              </p>
              <div className="flex items-center">
                <div className="h-10 w-10 rounded-full bg-gradient-to-r from-blue-400 to-purple-400 flex items-center justify-center text-white font-bold">
                  {testimonial.author[0]}
                </div>
                <div className="ml-3">
                  <p className="font-semibold">{testimonial.author}</p>
                  <p className="text-sm text-gray-500">{testimonial.position}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
