
import React from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";

interface Project {
  title: string;
  description: string;
  tags: string[];
  image: string;
  technologies: string;
}

const Portfolio = () => {
  const projects: Project[] = [
    {
      title: "EduStatus – Talabalar axborot tizimi",
      description: "Talabalar uchun qarzdorlik tekshirish platformasi",
      tags: ["Admin panel", "Login parol bilan boshqaruv"],
      image: "https://via.placeholder.com/400x250?text=EduStatus",
      technologies: "PHP, MySQL, Bootstrap"
    },
    {
      title: "MedAI – Telemeditsina AI bot",
      description: "Tibbiy maslahat beruvchi Telegram boti",
      tags: ["Python va Dialogflow asosida", "Real vaqtli foydalanuvchi yordami"],
      image: "https://via.placeholder.com/400x250?text=MedAI",
      technologies: "Python, Telegram Bot API, Dialogflow"
    },
    {
      title: "Personal Blog Platformasi",
      description: "Markdown asosida maqolalar yaratish va tahrirlash",
      tags: ["ReactJS", "Firebase"],
      image: "https://via.placeholder.com/400x250?text=Blog+Platform",
      technologies: "ReactJS, Firebase"
    }
  ];

  return (
    <section id="portfolio" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12 animate-fade-in">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">Portfolio</span>
          </h2>
          <div className="w-16 h-1.5 bg-blue-purple-gradient rounded-full mx-auto mb-4"></div>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Mening eng so'nggi loyihalarim va ishlangan dasturlarim
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <Card key={project.title} className="overflow-hidden transition-all hover:shadow-lg animate-fade-in" style={{ animationDelay: `${index * 100}ms` }}>
              <div className="aspect-video overflow-hidden">
                <img 
                  src={project.image} 
                  alt={project.title} 
                  className="w-full h-full object-cover transition-transform hover:scale-105"
                />
              </div>
              <CardHeader>
                <CardTitle className="text-lg md:text-xl">{project.title}</CardTitle>
                <CardDescription>{project.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2 mb-3">
                  {project.tags.map(tag => (
                    <span 
                      key={tag} 
                      className="text-xs px-2 py-1 rounded-full bg-blue-100 text-blue-700"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </CardContent>
              <CardFooter className="text-sm text-gray-500">
                <p>Texnologiyalar: {project.technologies}</p>
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Portfolio;
