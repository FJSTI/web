
import React from 'react';

const About = () => {
  return (
    <section id="about" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12 animate-fade-in">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Men <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">haqimda</span>
          </h2>
          <div className="w-16 h-1.5 bg-blue-purple-gradient rounded-full mx-auto"></div>
        </div>
        
        <div className="max-w-4xl mx-auto bg-white rounded-lg shadow-md p-8 animate-fade-in animate-delay-200">
          <div className="space-y-6 text-gray-700">
            <p className="text-lg leading-relaxed">
              Men <span className="font-semibold">Ashuraliyev Xondamir To'lqinjon o'g'li</span> – veb va tizim muhandisiman.
            </p>
            
            <p className="leading-relaxed">
              Vaqt o'tgan sayin tajribam ko'paymoqda: ilg'or texnologiyalar bilan ishlash, foydalanuvchiga yo'naltirilgan interfeyslar yaratish va murakkab muammolarni oddiy yechimlarga aylantirish mening kundalik ishlarimdir.
            </p>
            
            <p className="leading-relaxed">
              Veb-dasturlash, ma'lumotlar bazasi va tizim xavfsizligi kabi sohalarda chuqur bilim va amaliyotga egaman.
            </p>
            
            <p className="leading-relaxed font-medium text-gray-800">
              Har bir loyihaga – o'z ishim sifatida yondashaman.
            </p>
            
            <div className="flex flex-wrap gap-4 md:gap-10 pt-4">
              <div className="flex flex-col">
                <span className="font-bold text-3xl text-blue-600">3+</span>
                <span className="text-sm text-gray-500">Yillik tajriba</span>
              </div>
              
              <div className="flex flex-col">
                <span className="font-bold text-3xl text-blue-600">20+</span>
                <span className="text-sm text-gray-500">Loyihalar</span>
              </div>
              
              <div className="flex flex-col">
                <span className="font-bold text-3xl text-blue-600">10+</span>
                <span className="text-sm text-gray-500">Texnologiyalar</span>
              </div>
              
              <div className="flex flex-col">
                <span className="font-bold text-3xl text-blue-600">100%</span>
                <span className="text-sm text-gray-500">Mijoz mamnuniyati</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
