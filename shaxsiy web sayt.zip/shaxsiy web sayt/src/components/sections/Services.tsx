
import React from 'react';
import { Globe, MessageSquare, Server, PenTool } from 'lucide-react';

interface Service {
  icon: React.ReactNode;
  title: string;
  description: string;
}

const Services = () => {
  const services: Service[] = [
    {
      icon: <Globe className="w-12 h-12 text-blue-600" />,
      title: "Veb-sayt yaratish",
      description: "Zamonaviy, responsiv, SEO mos saytlar yarataman"
    },
    {
      icon: <MessageSquare className="w-12 h-12 text-purple-600" />,
      title: "Telegram bot",
      description: "Har xil funksional botlar (AI, savdo, chat)"
    },
    {
      icon: <Server className="w-12 h-12 text-blue-600" />,
      title: "Backend API",
      description: "Tezkor va xavfsiz REST API'lar ishlab chiqish"
    },
    {
      icon: <PenTool className="w-12 h-12 text-purple-600" />,
      title: "UI/UX dizayn",
      description: "Figma orqali interfeys loyihalash va prototiplash"
    }
  ];

  return (
    <section id="services" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12 animate-fade-in">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">Xizmatlar</span>
          </h2>
          <div className="w-16 h-1.5 bg-blue-purple-gradient rounded-full mx-auto mb-4"></div>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Mijozlar uchun taklif etadigan asosiy xizmatlarim
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((service, index) => (
            <div 
              key={service.title} 
              className="bg-white border border-gray-100 rounded-lg p-6 shadow-sm hover:shadow-md transition-all transform hover:-translate-y-1 animate-fade-in" 
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div className="flex flex-col items-center text-center">
                <div className="mb-4 p-3 bg-blue-50 rounded-full">
                  {service.icon}
                </div>
                <h3 className="font-bold text-xl mb-3">{service.title}</h3>
                <p className="text-gray-600">{service.description}</p>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-12 bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl p-8 text-white text-center animate-fade-in animate-delay-300">
          <h3 className="text-2xl font-bold mb-4">Loyiha bo'yicha maslahat kerakmi?</h3>
          <p className="mb-6">Har qanday loyiha g'oyangizni muhokama qilish uchun men bilan bog'laning</p>
          <a 
            href="#contact" 
            className="inline-block bg-white text-blue-600 font-semibold py-3 px-6 rounded-full hover:bg-blue-50 transition-colors"
          >
            Bog'lanish
          </a>
        </div>
      </div>
    </section>
  );
};

export default Services;
