
import React from 'react';
import { Github, Instagram, Linkedin, Mail } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-gradient-to-r from-blue-800 to-purple-800 text-white py-12">
      <div className="container mx-auto px-4">
        <div className="flex flex-col items-center">
          <h2 className="text-2xl font-bold mb-2">Ashuraliyev Xondamir</h2>
          <p className="text-blue-200 mb-6">Muhandis dasturchi, innovatsion veb-loyihalar muallifi</p>
          
          <div className="flex space-x-4 mb-8">
            <a 
              href="https://github.com/" 
              target="_blank" 
              rel="noreferrer" 
              className="bg-white/10 hover:bg-white/20 p-3 rounded-full transition-colors"
            >
              <Github size={20} />
            </a>
            
            <a 
              href="https://instagram.com/Xondamir_99_04" 
              target="_blank" 
              rel="noreferrer" 
              className="bg-white/10 hover:bg-white/20 p-3 rounded-full transition-colors"
            >
              <Instagram size={20} />
            </a>
            
            <a 
              href="https://linkedin.com/in/" 
              target="_blank" 
              rel="noreferrer" 
              className="bg-white/10 hover:bg-white/20 p-3 rounded-full transition-colors"
            >
              <Linkedin size={20} />
            </a>
            
            <a 
              href="mailto:xondamir@example.com" 
              className="bg-white/10 hover:bg-white/20 p-3 rounded-full transition-colors"
            >
              <Mail size={20} />
            </a>
          </div>
          
          <div className="text-center">
            <p className="text-sm text-blue-200 mb-2">
              &copy; {new Date().getFullYear()} Ashuraliyev Xondamir. Barcha huquqlar himoyalangan.
            </p>
            <p className="text-xs text-blue-300">
              Sayt Xondamir tomonidan yaratilgan
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
