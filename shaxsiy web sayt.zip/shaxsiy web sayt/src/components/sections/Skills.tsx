
import React, { useEffect, useRef, useState } from 'react';

interface Skill {
  name: string;
  percentage: number;
}

const Skills = () => {
  const skills: Skill[] = [
    { name: 'HTML5 / CSS3 / JavaScript', percentage: 95 },
    { name: 'Bootstrap / TailwindCSS', percentage: 92 },
    { name: 'ReactJS / Vue.js', percentage: 88 },
    { name: 'Node.js / Express', percentage: 85 },
    { name: 'MySQL / MongoDB', percentage: 83 },
    { name: 'Git / GitHub', percentage: 90 },
    { name: 'REST API integratsiya', percentage: 87 },
    { name: 'UI/UX Dizayn tushunchalari', percentage: 80 },
  ];
  
  const sectionRef = useRef<HTMLDivElement>(null);
  const [animate, setAnimate] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setAnimate(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => {
      observer.disconnect();
    };
  }, []);

  return (
    <section id="skills" className="py-20 bg-white" ref={sectionRef}>
      <div className="container mx-auto px-4">
        <div className="text-center mb-12 animate-fade-in">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">Ko'nikmalar</span>
          </h2>
          <div className="w-16 h-1.5 bg-blue-purple-gradient rounded-full mx-auto"></div>
        </div>
        
        <div className="max-w-4xl mx-auto">
          <div className="grid gap-6">
            {skills.map((skill, index) => (
              <div 
                key={skill.name} 
                className="animate-fade-in" 
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="flex justify-between mb-2">
                  <span className="font-medium text-gray-700">{skill.name}</span>
                  <span className="font-semibold text-blue-600">{skill.percentage}%</span>
                </div>
                <div className="skill-bar">
                  <div 
                    className="skill-progress" 
                    style={{ 
                      width: animate ? `${skill.percentage}%` : '0%', 
                      transition: `width 1s ease-out ${index * 0.2}s` 
                    }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Skills;
