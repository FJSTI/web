
import React from 'react';
import { Button } from "@/components/ui/button";
import { Download, Mail } from "lucide-react";

const Hero = () => {
  // CV ni yuklab olish uchun funksiya
  const downloadCV = () => {
    // CV PDF fayli manzilini ko'rsating
    const cvPath = '/xondamir_cv.pdf';
    
    // Yuklab olish uchun link yaratish
    const link = document.createElement('a');
    link.href = cvPath;
    link.download = 'Ashuraliyev_Xondamir_CV.pdf';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <section 
      id="home" 
      className="min-h-screen relative flex items-center justify-center overflow-hidden py-20 px-4"
    >
      {/* Background with gradient */}
      <div className="absolute inset-0 bg-blue-purple-gradient opacity-10 -z-10"></div>
      
      {/* Decorative elements */}
      <div className="absolute top-20 left-10 w-20 h-20 rounded-full bg-blue-200 opacity-50 animate-float -z-10"></div>
      <div className="absolute bottom-20 right-10 w-32 h-32 rounded-full bg-purple-200 opacity-50 animate-float -z-10" style={{ animationDelay: '1s' }}></div>
      
      <div className="container mx-auto">
        <div className="flex flex-col lg:flex-row items-center justify-between gap-12">
          
          {/* Text content */}
          <div className="lg:w-1/2 text-center lg:text-left animate-fade-in">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight">
              Salom, men <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">Ashuraliyev Xondamir</span>
            </h1>
            
            <p className="text-xl md:text-2xl font-medium text-gray-700 mb-4">
              Muhandis dasturchi, innovatsion veb-loyihalar muallifi
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start mt-8">
              <Button 
                className="bg-blue-purple-gradient hover:opacity-90 transition-all text-lg px-8 py-6 gap-2" 
                size="lg"
                onClick={downloadCV}
              >
                <Download size={20} />
                CV-ni yuklab olish
              </Button>
              
              <Button 
                variant="outline" 
                size="lg" 
                className="border-purple-300 text-gray-800 hover:bg-purple-50 text-lg px-8 py-6 gap-2"
                onClick={() => {
                  document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
                }}
              >
                <Mail size={20} />
                Bog'lanish
              </Button>
            </div>
          </div>
          
          {/* Profile image/silhouette */}
          <div className="lg:w-1/2 flex justify-center animate-fade-in animate-delay-300">
            <div className="relative w-64 h-64 md:w-80 md:h-80">
              {/* Circle background */}
              <div className="absolute inset-0 rounded-full bg-gradient-to-br from-blue-500/20 to-purple-500/20"></div>
              
              {/* Replace with actual profile image */}
              <div className="absolute inset-0 rounded-full overflow-hidden">
                <img 
                  src="/profile_image.jpg" 
                  alt="Ashuraliyev Xondamir" 
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
          </div>
          
        </div>
      </div>
      
      {/* Scroll down indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <div className="w-8 h-12 border-2 border-gray-700 rounded-full flex justify-center pt-1">
          <div className="w-1 h-3 bg-gray-700 rounded-full animate-float"></div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
