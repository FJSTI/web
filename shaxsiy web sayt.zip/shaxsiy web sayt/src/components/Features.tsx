
import React from 'react';
import { MessageSquare, Shield, Zap, Users } from "lucide-react";

const features = [
  {
    icon: <MessageSquare className="h-6 w-6 text-oasis-500" />,
    title: "Seamless Conversations",
    description: "Chat flows naturally with our intuitive interface, making every conversation feel personal."
  },
  {
    icon: <Shield className="h-6 w-6 text-oasis-500" />,
    title: "Private & Secure",
    description: "Your conversations are protected with end-to-end encryption for maximum privacy."
  },
  {
    icon: <Zap className="h-6 w-6 text-oasis-500" />,
    title: "Lightning Fast",
    description: "Experience rapid message delivery with our optimized chat infrastructure."
  },
  {
    icon: <Users className="h-6 w-6 text-oasis-500" />,
    title: "Community First",
    description: "Connect with friends and create meaningful communities in your personal oasis."
  }
];

const Features = () => {
  return (
    <section className="py-12 bg-oasis-50">
      <div className="container px-4 md:px-6">
        <div className="text-center mb-10">
          <h2 className="text-3xl font-bold tracking-tight text-oasis-800">Why Choose Salom</h2>
          <p className="mt-4 text-lg text-muted-foreground">
            Discover the features that make our chat experience unique
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => (
            <div 
              key={index}
              className="bg-white p-6 rounded-xl shadow-sm border border-oasis-100 hover:shadow-md transition-shadow"
            >
              <div className="h-12 w-12 rounded-full bg-oasis-100 flex items-center justify-center mb-4">
                {feature.icon}
              </div>
              <h3 className="font-medium text-lg mb-2">{feature.title}</h3>
              <p className="text-muted-foreground text-sm">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;
