
import React, { useState, useEffect, useRef } from 'react';
import { ScrollArea } from "@/components/ui/scroll-area";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Avatar } from "@/components/ui/avatar";
import { Send } from "lucide-react";
import ChatMessage from './ChatMessage';

type Message = {
  id: string;
  content: string;
  sender: 'user' | 'other';
  timestamp: Date;
};

const ChatInterface = () => {
  const [messages, setMessages] = useState<Message[]>([
    { 
      id: '1', 
      content: 'Welcome to Salom Chat! How can I help you today?', 
      sender: 'other', 
      timestamp: new Date() 
    }
  ]);
  const [newMessage, setNewMessage] = useState('');
  const scrollAreaRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    if (scrollAreaRef.current) {
      const scrollContainer = scrollAreaRef.current;
      scrollContainer.scrollTop = scrollContainer.scrollHeight;
    }
  }, [messages]);

  // Response messages
  const botResponses = [
    "That's interesting! Tell me more.",
    "I understand. How do you feel about that?",
    "Thank you for sharing that with me.",
    "I'm here to listen whenever you need someone to talk to.",
    "That's a great point!",
    "I see what you mean.",
    "Let's explore that idea further.",
    "How has your day been going?",
    "What else would you like to discuss today?",
    "It's so peaceful here in the oasis, isn't it?"
  ];

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (newMessage.trim() === '') return;
    
    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      content: newMessage,
      sender: 'user',
      timestamp: new Date()
    };
    
    setMessages(prev => [...prev, userMessage]);
    setNewMessage('');
    
    // Simulate response (after a short delay)
    setTimeout(() => {
      const randomResponse = botResponses[Math.floor(Math.random() * botResponses.length)];
      const botMessage: Message = {
        id: (Date.now() + 1).toString(),
        content: randomResponse,
        sender: 'other',
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, botMessage]);
    }, 1000);
  };

  return (
    <div className="h-full flex flex-col bg-white rounded-lg shadow-md overflow-hidden">
      {/* Chat header */}
      <div className="p-4 bg-oasis-50 border-b flex items-center space-x-3">
        <Avatar>
          <div className="w-10 h-10 rounded-full bg-oasis-300 flex items-center justify-center text-white font-medium">
            SO
          </div>
        </Avatar>
        <div>
          <h3 className="font-medium">Salom Oasis</h3>
          <p className="text-xs text-muted-foreground">Online</p>
        </div>
      </div>
      
      {/* Messages area */}
      <ScrollArea 
        ref={scrollAreaRef} 
        className="flex-1 p-4 desert-pattern"
      >
        <div className="space-y-4">
          {messages.map((message) => (
            <ChatMessage key={message.id} message={message} />
          ))}
        </div>
      </ScrollArea>
      
      {/* Input area */}
      <form onSubmit={handleSendMessage} className="p-4 border-t bg-oasis-50 flex gap-2">
        <Input
          value={newMessage}
          onChange={(e) => setNewMessage(e.target.value)}
          placeholder="Type your message..."
          className="flex-1 focus-visible:ring-oasis-300"
        />
        <Button type="submit" size="icon" className="bg-oasis-500 hover:bg-oasis-600">
          <Send className="h-4 w-4" />
        </Button>
      </form>
    </div>
  );
};

export default ChatInterface;
