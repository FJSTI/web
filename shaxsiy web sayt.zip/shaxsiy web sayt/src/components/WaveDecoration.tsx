
import React from 'react';

const WaveDecoration = () => {
  return (
    <div className="absolute bottom-0 left-0 right-0 h-64 z-0 overflow-hidden">
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320" className="absolute bottom-0 animate-float">
        <path 
          fill="#bae6fd" 
          fillOpacity="0.3" 
          d="M0,96L48,117.3C96,139,192,181,288,181.3C384,181,480,139,576,144C672,149,768,203,864,202.7C960,203,1056,149,1152,133.3C1248,117,1344,139,1392,149.3L1440,160L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"
        ></path>
      </svg>
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320" className="absolute bottom-0 animate-wave">
        <path 
          fill="#7dd3fc" 
          fillOpacity="0.2" 
          d="M0,288L48,272C96,256,192,224,288,218.7C384,213,480,235,576,240C672,245,768,235,864,224C960,213,1056,203,1152,202.7C1248,203,1344,213,1392,218.7L1440,224L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"
        ></path>
      </svg>
    </div>
  );
};

export default WaveDecoration;
