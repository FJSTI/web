
import React from 'react';
import { Avatar } from "@/components/ui/avatar";
import { cn } from "@/lib/utils";

type Message = {
  id: string;
  content: string;
  sender: 'user' | 'other';
  timestamp: Date;
};

type ChatMessageProps = {
  message: Message;
};

const ChatMessage = ({ message }: ChatMessageProps) => {
  const formatTime = (date: Date) => {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div
      className={cn(
        "flex items-end gap-2 max-w-[80%]",
        message.sender === 'user' ? "ml-auto justify-end" : ""
      )}
    >
      {message.sender === 'other' && (
        <Avatar className="w-8 h-8">
          <div className="w-full h-full rounded-full bg-oasis-300 flex items-center justify-center text-white font-medium text-xs">
            SO
          </div>
        </Avatar>
      )}

      <div className="flex flex-col">
        <div
          className={cn(
            message.sender === 'user' ? "chat-bubble-user" : "chat-bubble-other"
          )}
        >
          {message.content}
        </div>
        <span className={cn(
          "text-[10px] text-muted-foreground mt-1",
          message.sender === 'user' ? "text-right" : "text-left"
        )}>
          {formatTime(message.timestamp)}
        </span>
      </div>

      {message.sender === 'user' && (
        <Avatar className="w-8 h-8">
          <div className="w-full h-full rounded-full bg-sand-500 flex items-center justify-center text-white font-medium text-xs">
            ME
          </div>
        </Avatar>
      )}
    </div>
  );
};

export default ChatMessage;
